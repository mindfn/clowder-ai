import assert from 'node:assert/strict';
import { test } from 'node:test';
const root='/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api';
const {InvocationQueue}=await import(`${root}/dist/domains/cats/services/agents/invocation/InvocationQueue.js`);
const {MessageStore}=await import(`${root}/dist/domains/cats/services/stores/ports/MessageStore.js`);
const {AgentRouter}=await import(`${root}/dist/domains/cats/services/agents/routing/AgentRouter.js`);
const {AgentRegistry}=await import(`${root}/dist/domains/cats/services/agents/registry/AgentRegistry.js`);
const {InvocationRegistry}=await import(`${root}/dist/domains/cats/services/agents/invocation/InvocationRegistry.js`);
const {ThreadStore}=await import(`${root}/dist/domains/cats/services/stores/ports/ThreadStore.js`);
function envelope(targetCats=[]){const from={kind:'user',userId:'owner'};return [{from,userId:'owner',threadId:'thread',content:'hello',mentions:targetCats,deliveryStatus:'queued',timestamp:100,idempotencyKey:'fixed-request'}, {from,userId:'owner',threadId:'thread',content:'hello',kind:'conversation_input',ownerAuthProvenance:'strict',targetCats,intent:'execute'}];}
test('common send replay retains originally resolved no-mention target after fallback changes',async()=>{
 let fallback='opus'; const q=new InvocationQueue(undefined,{resolveTargets:async(ids)=>ids.length?[...ids]:[fallback]}); const m=new MessageStore();const args=envelope();
 const first=await q.send(m,...args);assert.deepEqual(first.entry.targets,['opus']); fallback='codex';
 const again=await q.send(m,...args);assert.equal(again.message.id,first.message.id);assert.deepEqual(again.entry.targets,['opus']);assert.equal(again.deduped,true);
});
test('known member registration failure remains admitted for normal failure settlement',async()=>{
 const services=new AgentRegistry();services.register('codex',{invoke:async function*(){}});services.markUnavailable('opus',{code:'rejected-account-binding',message:'fixture missing account'});
 const m=new MessageStore();const router=new AgentRouter({agentRegistry:services,registry:new InvocationRegistry(),messageStore:m,threadStore:new ThreadStore()});
 const resolved=await router.resolveTargetsAndIntent('@opus hello','thread',{persist:false,allowFallback:false});assert.deepEqual(resolved.targetCats,['opus']);
 const q=new InvocationQueue(undefined,{resolveTargets:(ids,t,content,exact)=>router.resolveSendTargets(ids,t,content,exact)});
 const [message,input]=envelope(resolved.targetCats); const result=await q.send(m,message,input);assert.equal(result.outcome,'enqueued');assert.equal(q.list('thread','owner').length,1);assert.deepEqual(result.entry.targets,['codex']);
});
test('new no-mention identities may resolve a new fallback',async()=>{
 let fallback='opus';const q=new InvocationQueue(undefined,{resolveTargets:async(ids)=>ids.length?[...ids]:[fallback]});const m=new MessageStore();const [message,input]=envelope();await q.send(m,message,input);fallback='codex';const result=await q.send(m,{...message,idempotencyKey:'new-request'},input);assert.deepEqual(result.entry.targets,['codex']);
});
test('HTTP authored mention of known registration failure is durably accepted',async(t)=>{
 const {createRequire}=await import('node:module');const require=createRequire(`${root}/package.json`);const Fastify=require('fastify');
 const {messagesRoutes}=await import(`${root}/dist/routes/messages.js`);
 const m=new MessageStore();const threads=new ThreadStore();const thread=threads.create('owner','owned');const registry=new InvocationRegistry();
 const services=new AgentRegistry();services.register('codex',{invoke:async function*(){}});services.markUnavailable('opus',{code:'rejected-account-binding',message:'fixture missing account'});
 const router=new AgentRouter({agentRegistry:services,registry,messageStore:m,threadStore:threads});
 const q=new InvocationQueue(undefined,{resolveTargets:(ids,id,content,exact)=>router.resolveSendTargets(ids,id,content,exact)});
 const app=Fastify();t.after(()=>app.close());await app.register(messagesRoutes,{registry,messageStore:m,threadStore:threads,invocationQueue:q,router,socketManager:{broadcastToRoom(){},emitToUser(){},broadcastAgentMessage(){}}});
 const response=await app.inject({method:'POST',url:'/api/messages',headers:{'x-cat-cafe-user':'owner'},payload:{threadId:thread.id,content:'@opus hello',idempotencyKey:'ae894cfc-3745-4dcf-a7c0-dbe76629baea'}});
 assert.equal(response.statusCode,202,response.body);assert.equal(q.list(thread.id,'owner').length,1);assert.deepEqual(response.json().entries.map(row=>row.targetCatId),['codex']);
});
