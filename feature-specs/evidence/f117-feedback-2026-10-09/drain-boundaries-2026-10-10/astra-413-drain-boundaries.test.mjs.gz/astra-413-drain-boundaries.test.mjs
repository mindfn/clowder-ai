import assert from 'node:assert/strict';
import { describe, it, mock } from 'node:test';
import { canonicalTestMessageInput, canonicalTestQueueInput } from '/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/test/helpers/message-from-fixtures.js';

const { InvocationQueue } = await import('/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/agents/invocation/InvocationQueue.js');
const { QueueProcessor } = await import('/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/agents/invocation/QueueProcessor.js');
const { InvocationTracker } = await import('/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/agents/invocation/InvocationTracker.js');
const { PersistedQueueDelivery } = await import(
  '/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/agents/invocation/PersistedQueueDelivery.js'
);
const { MessageStore, settleLifecycleResponseInputs } = await import(
  '/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/stores/ports/MessageStore.js'
);
let sequence = 0;

function deferred() {
  let resolve;
  const promise = new Promise((settle) => {
    resolve = settle;
  });
  return { promise, resolve };
}

function createHarness() {
  const queue = new InvocationQueue();
  const messageStore = new MessageStore();
  const invocationTracker = new InvocationTracker();
  const socketManager = { broadcastAgentMessage: mock.fn(), broadcastToRoom: mock.fn(), emitToUser: mock.fn() };
  const deps = {
    queue,
    invocationTracker,
    invocationRecordStore: { create: mock.fn(), get: mock.fn(async () => null), update: mock.fn() },
    router: {
      resolveExplicitTargets: mock.fn(async (targets) => [...targets]),
      resolveConversationTargetsAtAdmission: mock.fn(async (targets) => [...targets]),
      routeExecution: mock.fn(async function* () {}),
      ackCollectedCursors: mock.fn(async () => {}),
    },
    socketManager,
    messageStore,
    log: { info: mock.fn(), warn: mock.fn(), error: mock.fn() },
  };
  return { ...deps, processor: new QueueProcessor(deps, { retryDeferral: { baseDelayMs: 60_000 } }) };
}

async function admit(harness, overrides = {}) {
  sequence += 1;
  const queueInput = canonicalTestQueueInput({
    threadId: 'thread-1',
    userId: 'user-1',
    kind: 'conversation_input',
    ownerAuthProvenance: 'strict',
    sourceId: `phase-m-append-${sequence}`,
    content: `append body ${sequence}`,
    targetCats: ['opus'],
    intent: 'execute',
    ...overrides,
  });
  const result = await harness.queue.appendAndEnqueueDurable(
    harness.messageStore,
    canonicalTestMessageInput({
      threadId: 'thread-1',
      userId: queueInput.userId,
      catId: null,
      from: queueInput.from,
      content: queueInput.content,
      mentions: ['opus'],
      timestamp: Date.now(),
      deliveryStatus: 'queued',
      ...(overrides.messageSource ? { source: overrides.messageSource } : {}),
    }),
    queueInput,
  );
  assert.equal(result.outcome, 'enqueued');
  return result;
}

function bindRun(harness, dispatch) {
  const invocationId = `turn-phase-m-${sequence}`;
  const startedAt = Date.now();
  harness.invocationTracker.start('thread-1', 'opus', 'user-1', ['opus'], 'parent-phase-m');
  const response = harness.messageStore.append({
    from: { kind: 'agent', catId: 'opus' },
    userId: 'user-1',
    content: '',
    mentions: [],
    origin: 'stream',
    timestamp: startedAt,
    threadId: 'thread-1',
    lifecycle: {
      kind: 'response',
      orderKey: `${startedAt}:${invocationId}`,
      invocationId,
      targetId: 'opus',
      inputEntryIds: [],
      inputMessageIds: [],
      status: 'processing',
      startedAt,
    },
  });
  assert.equal(
    harness.invocationTracker.bindLifecycleActiveRun(
      {
        threadId: 'thread-1',
        targetId: 'opus',
        invocationId,
        responseMessageId: response.id,
        inputEntryIds: [],
        inputMessageIds: [],
        privateInputEntryIds: [],
        startedAt,
      },
      'parent-phase-m',
    ),
    true,
  );
  const releaseCarrier = harness.invocationTracker.bindAgentClientActiveRunDispatcher('thread-1', 'opus', {
    invocationId,
    capabilities: { append: true, steer: true },
    handle: { provider: 'anthropic', carrier: 'claude_agent_sdk', threadId: 's', turnId: 't' },
    dispatch,
  });
  assert.equal(typeof releaseCarrier, 'function');
  return { invocationId, response, releaseCarrier };
}

function bindCodexRun(harness, dispatch) {
  const invocationId = `turn-other-${sequence}`;
  const startedAt = Date.now();
  harness.invocationTracker.start('thread-1', 'codex', 'user-1', ['codex'], 'parent-phase-m');
  const response = harness.messageStore.append({
    from: { kind: 'agent', catId: 'codex' },
    userId: 'user-1',
    content: '',
    mentions: [],
    origin: 'stream',
    timestamp: startedAt,
    threadId: 'thread-1',
    lifecycle: {
      kind: 'response',
      orderKey: `${startedAt}:${invocationId}`,
      invocationId,
      targetId: 'codex',
      inputEntryIds: [],
      inputMessageIds: [],
      status: 'processing',
      startedAt,
    },
  });
  assert.equal(
    harness.invocationTracker.bindLifecycleActiveRun(
      {
        threadId: 'thread-1',
        targetId: 'codex',
        invocationId,
        responseMessageId: response.id,
        inputEntryIds: [],
        inputMessageIds: [],
        privateInputEntryIds: [],
        startedAt,
      },
      'parent-phase-m',
    ),
    true,
  );
  const releaseCarrier = harness.invocationTracker.bindAgentClientActiveRunDispatcher('thread-1', 'codex', {
    invocationId,
    capabilities: { append: true, steer: true },
    handle: { provider: 'anthropic', carrier: 'claude_agent_sdk', threadId: 's', turnId: 't' },
    dispatch,
  });
  assert.equal(typeof releaseCarrier, 'function');
  return { invocationId, response, releaseCarrier };
}

async function append(harness, admitted, run) {
  return harness.processor.appendExactEntry({
    threadId: 'thread-1',
    userId: 'user-1',
    entryId: admitted.entry.id,
    expectedQueueRevision: harness.queue.snapshotRevision('thread-1', 'user-1'),
    expectedRuns: [{ targetId: 'opus', invocationId: run.invocationId, responseMessageId: run.response.id }],
  });
}

const deliveredEmits = (harness) =>
  harness.socketManager.emitToUser.mock.calls
    .filter((call) => call.arguments[1] === 'messages_delivered')
    .flatMap((call) => call.arguments[2].messageIds);
const activeInputs = (harness) => harness.invocationTracker.getActiveSlots('thread-1')[0].activeRun.inputMessageIds;


it('independent: automatic Append respects an older same-target Queue barrier',async()=>{
 const h=createHarness();
 const first=await admit(h,{content:'older explicitly waiting input'});
 await h.queue.bindContinueCurrentIntentDurable('thread-1','user-1',first.entry.id,'opus',{requested:'next_work'});
 const later=await admit(h,{content:'later ordinary input'});
 const dispatch=mock.fn(async()=>({accepted:true,handle:{}})); bindRun(h,dispatch);
 await h.processor.requestDrain('thread-1');
 console.log(JSON.stringify({kind:'same-target-order',dispatches:dispatch.mock.calls.length,olderQueued:!!h.queue.getEntrySnapshot('thread-1','user-1',first.entry.id),laterQueued:!!h.queue.getEntrySnapshot('thread-1','user-1',later.entry.id)}));
 assert.equal(dispatch.mock.calls.length,0,'later automatic input must not overtake an older same-target Queue barrier');
});
it('independent: pending client Append does not block an unrelated target drain',async()=>{
 const h=createHarness(); const entered=deferred(); const release=deferred();
 await admit(h,{content:'append to opus'});
 bindRun(h,async()=>{entered.resolve();await release.promise;return {accepted:true,handle:{}};});
 const firstDrain=h.processor.requestDrain('thread-1'); await entered.promise;
 const otherDispatch=mock.fn(async()=>({accepted:true,handle:{}}));
 bindCodexRun(h,otherDispatch);
 const other=await admit(h,{content:'independent codex input',targetCats:['codex']});
 const secondDrain=h.processor.requestDrain('thread-1');
 await new Promise(resolve=>setTimeout(resolve,40));
 const callsBeforeRelease=otherDispatch.mock.calls.length;
 release.resolve(); await Promise.all([firstDrain,secondDrain]);
 await new Promise(resolve=>setTimeout(resolve,40));
 console.log(JSON.stringify({kind:'other-target-liveness',callsBeforeRelease,callsAfterRelease:otherDispatch.mock.calls.length,otherSource:other.message.id}));
 assert.equal(otherDispatch.mock.calls.length,1,'positive control: second target accepts after first releases');
 assert(callsBeforeRelease>0,'unrelated target must make progress before native Append ACK resolves');
});
