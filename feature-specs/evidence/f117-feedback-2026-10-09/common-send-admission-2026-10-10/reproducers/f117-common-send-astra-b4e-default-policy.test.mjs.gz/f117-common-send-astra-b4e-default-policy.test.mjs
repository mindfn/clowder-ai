import assert from 'node:assert/strict';
import { describe, it, mock } from 'node:test';
import { canonicalTestMessageInput, canonicalTestQueueInput } from '/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/test/helpers/message-from-fixtures.js';

const { InvocationQueue } = await import('/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/agents/invocation/InvocationQueue.js');
const { QueueProcessor } = await import('/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/agents/invocation/QueueProcessor.js');
const { InvocationTracker } = await import('/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/agents/invocation/InvocationTracker.js');
const { PersistedQueueDelivery } = await import(
  '/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/agents/invocation/PersistedQueueDelivery.js'
);
const { MessageStore, settleLifecycleResponseInputs } = await import(
  '/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/domains/cats/services/stores/ports/MessageStore.js'
);
let sequence = 0;

function deferred() {
  let resolve;
  const promise = new Promise((settle) => {
    resolve = settle;
  });
  return { promise, resolve };
}

async function waitFor(predicate) {
  for (let attempt = 0; attempt < 100; attempt++) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
  assert.fail('Queue progress did not converge');
}

function createHarness() {
  const queue = new InvocationQueue();
  const messageStore = new MessageStore();
  const invocationTracker = new InvocationTracker();
  const socketManager = { broadcastAgentMessage: mock.fn(), broadcastToRoom: mock.fn(), emitToUser: mock.fn() };
  const deps = {
    queue,
    invocationTracker,
    invocationRecordStore: { create: mock.fn(), get: mock.fn(async () => null), update: mock.fn() },
    router: {
      resolveExplicitTargets: mock.fn(async (targets) => [...targets]),
      resolveConversationTargetsAtAdmission: mock.fn(async (targets) => [...targets]),
      routeExecution: mock.fn(async function* () {}),
      ackCollectedCursors: mock.fn(async () => {}),
    },
    socketManager,
    messageStore,
    log: { info: mock.fn(), warn: mock.fn(), error: mock.fn() },
  };
  return { ...deps, processor: new QueueProcessor(deps, { retryDeferral: { baseDelayMs: 60_000 } }) };
}

async function admit(harness, overrides = {}) {
  sequence += 1;
  const queueInput = canonicalTestQueueInput({
    threadId: 'thread-1',
    userId: 'user-1',
    kind: 'conversation_input',
    ownerAuthProvenance: 'strict',
    sourceId: `phase-m-append-${sequence}`,
    content: `append body ${sequence}`,
    targetCats: ['opus'],
    intent: 'execute',
    ...overrides,
  });
  const result = await harness.queue.send(
    harness.messageStore,
    canonicalTestMessageInput({
      threadId: 'thread-1',
      userId: queueInput.userId,
      catId: null,
      from: queueInput.from,
      content: queueInput.content,
      mentions: ['opus'],
      timestamp: Date.now(),
      deliveryStatus: 'queued',
      ...(overrides.messageSource ? { source: overrides.messageSource } : {}),
    }),
    queueInput,
  );
  assert.equal(result.outcome, 'enqueued');
  return result;
}

function bindRun(harness, dispatch, targetId = 'opus') {
  const invocationId = `turn-phase-m-${sequence}-${targetId}`;
  const startedAt = Date.now();
  harness.invocationTracker.start('thread-1', targetId, 'user-1', [targetId], 'parent-phase-m');
  const response = harness.messageStore.append({
    from: { kind: 'agent', catId: targetId },
    userId: 'user-1',
    content: '',
    mentions: [],
    origin: 'stream',
    timestamp: startedAt,
    threadId: 'thread-1',
    lifecycle: {
      kind: 'response',
      orderKey: `${startedAt}:${invocationId}`,
      invocationId,
      targetId,
      inputEntryIds: [],
      inputMessageIds: [],
      status: 'processing',
      startedAt,
    },
  });
  assert.equal(
    harness.invocationTracker.bindLifecycleActiveRun(
      {
        threadId: 'thread-1',
        targetId,
        invocationId,
        responseMessageId: response.id,
        inputEntryIds: [],
        inputMessageIds: [],
        privateInputEntryIds: [],
        startedAt,
      },
      'parent-phase-m',
    ),
    true,
  );
  const releaseCarrier = harness.invocationTracker.bindAgentClientActiveRunDispatcher('thread-1', targetId, {
    invocationId,
    capabilities: { append: true, steer: true },
    handle: { provider: 'anthropic', carrier: 'claude_agent_sdk', threadId: 's', turnId: 't' },
    dispatch,
  });
  assert.equal(typeof releaseCarrier, 'function');
  return { invocationId, response, releaseCarrier };
}

async function append(harness, admitted, run) {
  return harness.processor.appendExactEntry({
    threadId: 'thread-1',
    userId: 'user-1',
    entryId: admitted.entry.id,
    expectedQueueRevision: harness.queue.snapshotRevision('thread-1', 'user-1'),
    expectedRuns: [{ targetId: 'opus', invocationId: run.invocationId, responseMessageId: run.response.id }],
  });
}

const deliveredEmits = (harness) =>
  harness.socketManager.emitToUser.mock.calls
    .filter((call) => call.arguments[1] === 'messages_delivered')
    .flatMap((call) => call.arguments[2].messageIds);
const activeInputs = (harness) => harness.invocationTracker.getActiveSlots('thread-1')[0].activeRun.inputMessageIds;


const {resolveMessageDispositionForAdmission}=await import('/Users/lang/workspace/github-lab/cat-cafe-append-receipt-feedback/packages/api/dist/routes/message-disposition-admission.js');

for(const from of [{kind:'user',userId:'user-1'},{kind:'agent',catId:'codex'},{kind:'external',connectorId:'github-wait',sender:{id:'github-wait'}},{kind:'system',service:'scheduler'}])
it(`independent common default policy: ${from.kind}`,async()=>{
 const h=createHarness(); const dispatch=mock.fn(async()=>({accepted:true,handle:{}})); bindRun(h,dispatch);
 const input=await admit(h,{from});
 const effective=resolveMessageDispositionForAdmission({threadId:'thread-1'});
 assert.equal(effective,'next_work','product-default positive control');
 // Mirror the current real ingress: only messages.ts supplies this intent.
 if(from.kind==='user')await h.queue.bindContinueCurrentIntentDurable('thread-1','user-1',input.entry.id,'opus',{requested:effective});
 await h.processor.requestDrain('thread-1');
 console.log(JSON.stringify({source:from.kind,effective,dispatches:dispatch.mock.calls.length}));
 assert.equal(dispatch.mock.calls.length,0,'same default next_work must apply regardless of source');
});
